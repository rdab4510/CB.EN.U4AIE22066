// src/services/stockService.js
import axios from 'axios';

// Configuration
const BASE_URL = 'http://20.244.56.144/evaluation-service';

// Authentication credentials
const AUTH_CREDENTIALS = {
  email: "abhiramnasa@gmail.com",
  name: "abhiramaraju rallabandi",
  rollNo: "cb.en.u4aie22066",
  accessCode: "SwuuKE",
  clientID: "c3a14f11-6161-43aa-8b1d-762c71eddb0d",
  clientSecret: "cxuXWmRnDrWHyQag"
};

class StockService {
  constructor() {
    this.authToken = null;
    this.axiosInstance = axios.create({
      baseURL: BASE_URL,
      timeout: 15000, // Increased timeout to 15 seconds
    });

    // Setup global error handling
    this.setupInterceptors();
  }

  // Comprehensive interceptor setup
  setupInterceptors() {
    // Request interceptor
    this.axiosInstance.interceptors.request.use(
      async (config) => {
        try {
          // Ensure we have a valid token
          await this.getAuthToken();
          
          // Add token to request headers
          if (this.authToken) {
            config.headers.Authorization = `Bearer ${this.authToken}`;
          }
          return config;
        } catch (error) {
          console.error('Request Interceptor Error:', error);
          return Promise.reject(error);
        }
      },
      (error) => Promise.reject(error)
    );

    // Response interceptor
    this.axiosInstance.interceptors.response.use(
      (response) => response,
      async (error) => {
        const originalRequest = error.config;

        // Handle token expiration or unauthorized access
        if (error.response?.status === 401 && !originalRequest._retry) {
          originalRequest._retry = true;
          
          try {
            // Force token refresh
            await this.getAuthToken(true);
            
            // Retry the original request
            return this.axiosInstance(originalRequest);
          } catch (refreshError) {
            console.error('Token Refresh Failed:', refreshError);
            return Promise.reject(refreshError);
          }
        }

        return Promise.reject(error);
      }
    );
  }

  // Comprehensive token retrieval method
  async getAuthToken(forceRefresh = false) {
    // If we have a valid token and not forcing refresh, return it
    if (!forceRefresh && this.authToken) {
      return this.authToken;
    }

    try {
      const response = await axios.post(`${BASE_URL}/auth`, AUTH_CREDENTIALS, {
        timeout: 10000 // Specific timeout for auth request
      });
      
      // Store the new token
      this.authToken = response.data.access_token;
      
      return this.authToken;
    } catch (error) {
      console.error('Authentication Detailed Error:', {
        message: error.message,
        code: error.code,
        status: error.response?.status,
        data: error.response?.data
      });
      
      throw new Error(`Authentication failed: ${error.message}`);
    }
  }

  // Debug method to check connectivity and authentication
  async diagnoseConnection() {
    try {
      console.log('Diagnosing connection...');
      
      // Check basic network connectivity
      await axios.get('https://www.google.com', { timeout: 5000 });
      console.log('Internet connection: OK');
      
      // Attempt authentication
      const token = await this.getAuthToken(true);
      console.log('Authentication token retrieved successfully');
      
      // Try to fetch stocks
      const stocks = await this.fetchStocks();
      console.log('Stocks fetched successfully:', Object.keys(stocks));
      
      return {
        internetConnection: true,
        authentication: true,
        stocksFetched: true
      };
    } catch (error) {
      console.error('Diagnosis Failed:', {
        message: error.message,
        stack: error.stack
      });
      
      return {
        internetConnection: false,
        authentication: false,
        stocksFetched: false,
        error: error.message
      };
    }
  }

  // Fetch stocks with enhanced error handling
  async fetchStocks() {
    try {
      console.log('Attempting to fetch stocks...');
      
      const response = await this.axiosInstance.get('/stocks');
      
      if (!response.data || !response.data.stocks) {
        throw new Error('Invalid response structure');
      }
      
      console.log('Stocks fetched successfully');
      return response.data.stocks;
    } catch (error) {
      console.error('Detailed Fetch Stocks Error:', {
        message: error.message,
        code: error.code,
        status: error.response?.status,
        data: error.response?.data
      });
      
      // Additional diagnostic information
      await this.diagnoseConnection();
      
      throw new Error(`Failed to fetch stocks: ${error.message}`);
    }
  }

  // Fetch stock prices with enhanced error handling
  async fetchStockPrices(ticker, minutes = 50) {
    try {
      console.log(`Attempting to fetch prices for ${ticker}...`);
      
      const response = await this.axiosInstance.get(`/stocks/${ticker}`, {
        params: { minutes }
      });
      
      if (!response.data) {
        throw new Error('No price data received');
      }
      
      console.log(`Prices fetched successfully for ${ticker}`);
      return response.data;
    } catch (error) {
      console.error(`Detailed Fetch Prices Error for ${ticker}:`, {
        message: error.message,
        code: error.code,
        status: error.response?.status,
        data: error.response?.data
      });
      
      throw new Error(`Failed to fetch prices for ${ticker}: ${error.message}`);
    }
  }
}

// Create a singleton instance
const stockService = new StockService();

// Standalone functions for easy importing
export const fetchStocks = () => stockService.fetchStocks();
export const fetchStockPrices = (ticker, minutes) => 
  stockService.fetchStockPrices(ticker, minutes);

export { stockService };
export default stockService;