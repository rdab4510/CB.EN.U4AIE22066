import _ from 'lodash';

export const calculateCovariance = (x, y) => {
  if (x.length !== y.length || x.length === 0) return 0;

  const meanX = _.mean(x);
  const meanY = _.mean(y);

  const covariance = _.sum(x.map((xi, i) => 
    (xi - meanX) * (y[i] - meanY)
  )) / (x.length - 1);

  return covariance;
};

export const calculateStandardDeviation = (data) => {
  if (data.length === 0) return 0;

  const mean = _.mean(data);
  const variance = _.sum(data.map(val => 
    Math.pow(val - mean, 2)
  )) / (data.length - 1);

  return Math.sqrt(variance);
};

export const calculatePearsonCorrelation = (x, y) => {
  if (x.length !== y.length || x.length === 0) return 0;

  const covariance = calculateCovariance(x, y);
  const stdDevX = calculateStandardDeviation(x);
  const stdDevY = calculateStandardDeviation(y);

  return covariance / (stdDevX * stdDevY);
};
