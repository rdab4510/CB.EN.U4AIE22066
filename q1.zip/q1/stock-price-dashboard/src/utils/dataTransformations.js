export const normalizeData = (data) => {
  const min = Math.min(...data);
  const max = Math.max(...data);
  return data.map(val => 
    max === min ? 0 : (val - min) / (max - min)
  );
};
