import React, { useState } from 'react';
import { 
  Container, 
  AppBar, 
  Toolbar, 
  Typography, 
  Tabs, 
  Tab, 
  Box 
} from '@mui/material';
import { StockChart } from './components/StockChart';
import { CorrelationHeatmap } from './components/CorrelationHeatmap';
import { StockSelector } from './components/StockSelector';

const App = () => {
  const [selectedTab, setSelectedTab] = useState(0);
  const [selectedStock, setSelectedStock] = useState('');

  return (
    <Container maxWidth="lg">
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6">
            Stock Price Aggregation Dashboard
          </Typography>
        </Toolbar>
      </AppBar>
      
      <Tabs 
        value={selectedTab} 
        onChange={(_, newValue) => setSelectedTab(newValue)}
      >
        <Tab label="Stock Price Chart" />
        <Tab label="Correlation Heatmap" />
      </Tabs>

      {selectedTab === 0 && (
        <Box>
          <StockSelector onStockSelect={setSelectedStock} />
          {selectedStock && <StockChart ticker={selectedStock} />}
        </Box>
      )}

      {selectedTab === 1 && <CorrelationHeatmap />}
    </Container>
  );
};

export default App;
