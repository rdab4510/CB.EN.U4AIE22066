// src/index.js
import React from 'react';
import ReactDOM from 'react-dom/client';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import App from './App';

// Create a theme instance
const theme = createTheme({
  palette: {
    mode: 'dark', // You can switch to 'light' if preferred
    primary: {
      main: '#1976d2', // Customizable primary color
    },
    background: {
      default: '#121212', // Dark mode background
      paper: '#1d1d1d', // Slightly lighter background for paper components
    },
  },
  typography: {
    fontFamily: [
      '-apple-system',
      'BlinkMacSystemFont',
      '"Segoe UI"',
      'Roboto',
      '"Helvetica Neue"',
      'Arial',
      'sans-serif'
    ].join(','),
  },
  components: {
    MuiCssBaseline: {
      styleOverrides: `
        body {
          scrollbar-width: thin;
          scrollbar-color: #6b6b6b #2b2b2b;
        }
        body::-webkit-scrollbar {
          width: 8px;
        }
        body::-webkit-scrollbar-track {
          background: #2b2b2b;
        }
        body::-webkit-scrollbar-thumb {
          background-color: #6b6b6b;
          border-radius: 6px;
          border: 3px solid #2b2b2b;
        }
      `,
    },
  },
});

// Get the root element
const rootElement = document.getElementById('root');

// Create a root using createRoot
const root = ReactDOM.createRoot(rootElement);

// Render the app
root.render(
  <React.StrictMode>
    <ThemeProvider theme={theme}>
      <CssBaseline /> {/* Normalize CSS */}
      <App />
    </ThemeProvider>
  </React.StrictMode>
);