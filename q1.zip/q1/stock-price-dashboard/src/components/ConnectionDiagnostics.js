// src/components/ConnectionDiagnostics.js
import React, { useState, useEffect } from 'react';
import { 
  Button, 
  Typography, 
  Container, 
  Paper, 
  CircularProgress,
  Box
} from '@mui/material';
import { stockService } from '../services/stockService';

const ConnectionDiagnostics = () => {
  const [diagnosticResults, setDiagnosticResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const runDiagnostics = async () => {
    setLoading(true);
    setError(null);
    setDiagnosticResults(null);

    try {
      const results = await stockService.diagnoseConnection();
      setDiagnosticResults(results);
    } catch (err) {
      console.error('Diagnostics failed:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Automatically run diagnostics on component mount
    runDiagnostics();
  }, []);

  return (
    <Container maxWidth="md">
      <Paper elevation={3} sx={{ p: 3, mt: 4 }}>
        <Typography variant="h5" gutterBottom>
          Connection Diagnostics
        </Typography>

        {loading && (
          <Box display="flex" justifyContent="center" alignItems="center" mb={2}>
            <CircularProgress />
            <Typography sx={{ ml: 2 }}>
              Running diagnostics...
            </Typography>
          </Box>
        )}

        {error && (
          <Typography color="error" variant="body1" gutterBottom>
            Error: {error}
          </Typography>
        )}

        {diagnosticResults && (
          <Box>
            <Typography variant="subtitle1">
              Diagnostic Results:
            </Typography>
            <Typography>
              Internet Connection: {diagnosticResults.internetConnection ? '✅ OK' : '❌ Failed'}
            </Typography>
            <Typography>
              Authentication: {diagnosticResults.authentication ? '✅ Successful' : '❌ Failed'}
            </Typography>
            <Typography>
              Stocks Fetched: {diagnosticResults.stocksFetched ? '✅ Successful' : '❌ Failed'}
            </Typography>
            {diagnosticResults.error && (
              <Typography color="error">
                Error Details: {diagnosticResults.error}
              </Typography>
            )}
          </Box>
        )}

        <Box mt={2}>
          <Button 
            variant="contained" 
            color="primary" 
            onClick={runDiagnostics}
            disabled={loading}
          >
            Re-run Diagnostics
          </Button>
        </Box>
      </Paper>
    </Container>
  );
};

export default ConnectionDiagnostics;