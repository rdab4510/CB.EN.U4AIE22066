import React, { useState, useEffect } from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid 
} from 'recharts';
import { 
  Typography, 
  Box, 
  Select, 
  MenuItem, 
  FormControl, 
  InputLabel 
} from '@mui/material';
import { fetchStockPrices } from '../services/stockService';

export const StockChart = ({ ticker }) => {
  const [prices, setPrices] = useState([]);
  const [timeFrame, setTimeFrame] = useState(50);

  useEffect(() => {
    const loadStockPrices = async () => {
      const fetchedPrices = await fetchStockPrices(ticker, timeFrame);
      setPrices(fetchedPrices);
    };

    if (ticker) {
      loadStockPrices();
      const interval = setInterval(loadStockPrices, 60000); // Refresh every minute
      return () => clearInterval(interval);
    }
  }, [ticker, timeFrame]);

  const chartData = prices.map((price, index) => ({
    index,
    price: price.price,
    time: new Date(price.lastUpdatedAt).toLocaleTimeString()
  }));

  const averagePrice = prices.length 
    ? prices.reduce((sum, p) => sum + p.price, 0) / prices.length 
    : 0;

  return (
    <Box>
      <Typography variant="h6">
        {ticker} Stock Price (Last {timeFrame} Minutes)
      </Typography>
      <FormControl>
        <InputLabel>Time Frame</InputLabel>
        <Select
          value={timeFrame}
          onChange={(e) => setTimeFrame(Number(e.target.value))}
        >
          {[10, 30, 50, 100].map((frame) => (
            <MenuItem key={frame} value={frame}>
              {frame} Minutes
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <LineChart 
        width={800} 
        height={400} 
        data={chartData}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="time" />
        <YAxis />
        <Tooltip />
        <Line 
          type="monotone" 
          dataKey="price" 
          stroke="#8884d8" 
          dot={{ r: 5 }}
        />
        <Line 
          type="monotone" 
          dataKey={() => averagePrice} 
          stroke="red" 
          dot={false} 
          strokeDasharray="5 5"
        />
      </LineChart>
      <Typography variant="subtitle1">
        Average Price: ${averagePrice.toFixed(2)}
      </Typography>
    </Box>
  );
};
