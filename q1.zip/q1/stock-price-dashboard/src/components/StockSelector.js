import React, { useState, useEffect } from 'react';
import { 
  Select, 
  MenuItem, 
  FormControl, 
  InputLabel 
} from '@mui/material';
import { fetchStocks } from '../services/stockService';

export const StockSelector = ({ onStockSelect }) => {
  const [stocks, setStocks] = useState({});
  const [selectedStock, setSelectedStock] = useState('');

  useEffect(() => {
    const loadStocks = async () => {
      const fetchedStocks = await fetchStocks();
      setStocks(fetchedStocks);
    };
    loadStocks();
  }, []);

  const handleStockChange = (event) => {
    const ticker = event.target.value;
    setSelectedStock(ticker);
    onStockSelect(ticker);
  };

  return (
    <FormControl fullWidth>
      <InputLabel>Select Stock</InputLabel>
      <Select
        value={selectedStock}
        label="Select Stock"
        onChange={handleStockChange}
      >
        {Object.entries(stocks).map(([name, ticker]) => (
          <MenuItem key={ticker} value={ticker}>
            {name} ({ticker})
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
};
