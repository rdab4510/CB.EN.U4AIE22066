import React, { useState, useEffect } from 'react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Paper, 
  Typography 
} from '@mui/material';
import { fetchStocks, fetchStockPrices } from '../services/stockService';
import { 
  calculatePearsonCorrelation, 
  calculateStandardDeviation 
} from '../utils/correlationCalculator';
import { normalizeData } from '../utils/dataTransformations';

export const CorrelationHeatmap = () => {
  const [stocks, setStocks] = useState({});
  const [correlationMatrix, setCorrelationMatrix] = useState([]);
  const [stockStats, setStockStats] = useState({});

  useEffect(() => {
    const calculateCorrelations = async () => {
      const fetchedStocks = await fetchStocks();
      setStocks(fetchedStocks);

      const tickers = Object.values(fetchedStocks);
      const stockPrices = {};
      const stockStatistics = {};

      // Fetch prices for all stocks
      for (const ticker of tickers) {
        const prices = await fetchStockPrices(ticker);
        stockPrices[ticker] = prices.map(p => p.price);
        
        const priceValues = stockPrices[ticker];
        stockStatistics[ticker] = {
          avg: priceValues.reduce((a, b) => a + b, 0) / priceValues.length,
          stdDev: calculateStandardDeviation(priceValues)
        };
      }

      // Calculate correlation matrix
      const matrix = tickers.map((ticker1) => 
        tickers.map((ticker2) => {
          const normalizedX = normalizeData(stockPrices[ticker1]);
          const normalizedY = normalizeData(stockPrices[ticker2]);
          return calculatePearsonCorrelation(normalizedX, normalizedY);
        })
      );

      setCorrelationMatrix(matrix);
      setStockStats(stockStatistics);
    };

    calculateCorrelations();
  }, []);

  const getCorrelationColor = (correlation) => {
    if (correlation > 0.7) return 'darkgreen';
    if (correlation > 0.3) return 'lightgreen';
    if (correlation > -0.3) return 'gray';
    if (correlation > -0.7) return 'pink';
    return 'red';
  };

  return (
    <Paper>
      <Typography variant="h6">Stock Correlation Heatmap</Typography>
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Stocks</TableCell>
              {Object.values(stocks).map(ticker => (
                <TableCell key={ticker}>{ticker}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {Object.values(stocks).map((ticker1, i) => (
              <TableRow key={ticker1}>
                <TableCell>{ticker1}</TableCell>
                {Object.values(stocks).map((ticker2, j) => (
                  <TableCell 
                    key={ticker2} 
                    style={{ 
                      backgroundColor: getCorrelationColor(correlationMatrix[i]?.[j] || 0),
                      color: 'white',
                      fontWeight: 'bold'
                    }}
                  >
                    {(correlationMatrix[i]?.[j] || 0).toFixed(2)}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
};
